# Disclaimer
By viewing or using this mod, you agree that you are voided from binding any legal disputes or change of Java Cups™ according to the terms below.

Additional repercussions of violation of these terms include voiding particaption in the "You are one of us™" program.

### Terms:
1. If you give us a score of less than a 5 Java Cups™ for any reason below, your warranty will be voided.
2. We are not responsible for any damages caused to your machine of execution due to mismanagement of weapons of mass destruction.
3. Your warranty will be voided if you deduct Java Cups™ or create a legal dispute regarding internal music that does not fit your taste.
4. You may deduct Java Cups™ if the software does not run as intended.
5. You may not deduct Java Cups™ because you refused to read and agree to the Terms of Service.
6. If you mismanage the mods weapons and create a relation(s) of hostility due to such circumstances, you agree that our employees are to be released from any legal disputes regarding such.
7. Employees may not be removed from the space of demonstration if any of the terms apply.
8. You reserve the right to not view the presentation of this product, however, you may not deduct Java Cups™ because you refused to view this product.

Java Cups™ is a product of HolmerClassroom®.